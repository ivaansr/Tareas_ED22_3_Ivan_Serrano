
// Angel Ivan Serrano Rodriguez

let símbolo =" _._______ "
console.log(símbolo)
símbolo = "| _______ |"
console.log(símbolo)
símbolo = "||,-----.||"
console.log(símbolo)
símbolo = "|||     |||"
console.log(símbolo)
símbolo = "|||_____|||"
console.log(símbolo)
símbolo = "|`-------'|"
console.log(símbolo)
símbolo = "| +     O |"
console.log(símbolo)
símbolo = "|      O  |"
console.log(símbolo)
símbolo = "| //      | "
console.log(símbolo)
símbolo = "'---------' "
console.log(símbolo)
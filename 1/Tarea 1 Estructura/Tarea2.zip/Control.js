console.log("Iniciando simulación de combate")
console.log("Preparando terreno")
console.log("Tu equipo se encuentra en la arena")
console.log("Escoge paquete de armas")
console.log("1. Rifle de asalto/granada de fragmentación")
console.log("2. Rifle de batalla/magnum")
console.log("3. Aguijoneador/granada incendiaria")
console.log("4. Escopeta/granada de pinchos")

let combo = 4

if (combo ==1){
    console.log("Eliminas a todos tus enemigos")
    console.log("Das el tiro de gracia")
    console.log("Recuperas el artefacto")
}else if(combo == 2){
    console.log("Ráfagas cortas inutiles")
    console.log("Te quedas sin munición")
    console.log("Apenas logras salir vivo")
}else if(combo == 3){
    console.log("Encuentras armas enemigas")
    console.log("Armas efectivas contra los enemigos")
    console.log("Estas dominando la batalla")
    console.log("Unbelievable")
}else if(combo == 4){
    console.log("No trajiste mejores armas?")
    console.log("Estas perdido hijo")
    console.log("Game Over")
}